function check_name(el){
    var user = el.user_name.value;
    var fail = "";

    if(user =="")
        fail = "Заполните поле с именем!";
    else if(user.length <=1 || user.length > 50)
        fail = "Введите значение в пределах от 1 до 50 символов!";

    if(fail != ""){
    document.getElementById('error').innerHTML = fail;
    return false;
    } else{
        localStorage["tetris.username"] = user;
        window.location = 'https://localhost/main.html';
        return false;
    }
}