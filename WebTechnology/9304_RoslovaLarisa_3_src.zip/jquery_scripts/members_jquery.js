$(document).ready(()=>{

    $("#button_addPerson").click(function(){
        $("#add_person").show();
        $('#form_delPerson').css('margin-top', '-228px');
    });
    $('#close').click(function (){
        $('#add_person').hide();
        $('#form_delPerson').css('margin-top', '0');
    });
    $("#add_newMember").click(function (){
        $('#add_person').hide();
        $('#form_delPerson').css('margin-top', '0');
        $.get('/add_person', {
            name: $("#name").val(),
            money: $("#money").val()
        }).done((data)=>{
            let person = JSON.parse(data);
            $('table').append(
                `<tr id = ${person.id}>
                    <td>${person.id}</td>
                    <td>${person.name}</td>
                    <td>${person.money}</td></tr>`)
        })
    })

    $("#del_pers").click(function(){
        $("#form_delPerson").show();
    });
    $('#exit').click(function (){
        $('#form_delPerson').hide();
    });
    $("#delete_pers").click(function (){
        $('#form_delPerson').hide();
        $.get('/delete_person', {
            id_pers: $("#person_del").val()
        }).done(function (data){
            console.log(data);
            $(`#${data}`).remove();
        })
    })

    $("#open_money").click(function(){
        $("#edit_money").show();
    });
    $('#closeMoney').click(function (){
        $('#edit_money').hide();
    });


});