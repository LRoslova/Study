$(document).ready(()=>{

    $("#button_settings").click(function(){
        $.get('/set_settings', {
            date_s: $("#date_s").val(),
            time_s: $("#time_s").val(),
            timeout: $("#timeout").val(),
            pause: $("#pause").val(),
            torg: $("#torg").val(),
        }).done((data)=>{
            let set = JSON.parse(data);
            $('#date_s').val(set.date_s);
            $('#time_s').val(set.time_s);
            $('#timeout').val(set.timeout);
            $('#pause').val(set.pause);
            $('#torg').val(set.torg);
        })
    })

    $("#del_pers").click(function(){
        $("#form_delPerson").show();
    });
    $('#exit').click(function (){
        $('#form_delPerson').hide();
    });
    $("#delete_pers").click(function (){
        $('#form_delPerson').hide();
        $.get('/delete_person', {
            id_pers: $("#person_del").val()
        }).done(function (data){
            console.log(data);
            $(`#${data}`).remove();
        })
    })

    $("#open_money").click(function(){
        $("#edit_money").show();
    });
    $('#closeMoney').click(function (){
        $('#edit_money').hide();
    });


});