$(document).ready(()=>{

    $("#button_addLot").click(function(){
        $("#add_lot").show();
        $('#form_del').css('margin-top', '-390px')
    });
    $('#close').click(function (){
        $('#add_lot').hide();
        $('#form_del').css('margin-top', '0')
    });
    $("#add").click(function (){
        $('#add_lot').hide();
        $('#form_del').css('margin-top', '0')
        $.get('/add_lot', {
            path: $("#url").val(),
            title: $("#title").val(),
            author: $("#author").val(),
            info: $("#info").val(),
            min_step: $("#min_step").val(),
            max_step: $("#max_step").val(),
            price: $("#price").val(),
            year: $("#year").val()
        }).done((data)=>{
            let lot = JSON.parse(data);
            $('table').append(
                `<tr id = ${lot.id}>
                    <td>${lot.id}</td>
                    <td> <img src=${lot.path} alt="no work"> </td>
                    <td>${lot.title}</td></tr>`)
        })
    })


    $("#del_but").click(function(){
        $("#form_del").show();
    });
    $('#exit').click(function (){
        $('#form_del').hide();
    });
    $("#delete_lot").click(function (){
        $('#form_del').hide();
        $.get('/delete_lot', {
            id_del: $("#title_del").val()
        }).done(function (data){
            console.log(data);
            //let id = data;
            $(`#${data}`).remove();
        })
    })

});
