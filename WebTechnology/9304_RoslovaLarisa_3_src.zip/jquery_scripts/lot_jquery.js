$(document).ready(()=>{

    $("#openForm").click(function(){
        $("#edit_lot").show();
    });
    $('#close').click(function (){
        $('#edit_lot').hide();
    });
    $("#save").click(function (){
        $('#edit_lot').hide();
    })

});