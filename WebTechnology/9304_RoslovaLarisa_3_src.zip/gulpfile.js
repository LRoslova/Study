const gulpfile = require('gulp');
const less = require('gulp-less');
const cleanCSS = require('gulp-clean-css');
const babel = require('gulp-babel');
const del = require('del');
const concat = require('gulp-concat');

function less_to_css(){
    return gulpfile.src('./public/less/*.less')
        .pipe(less())
        .pipe(cleanCSS())
        .pipe(gulpfile.dest('./public/css/'));
};

function scripts(){
    return gulpfile.src('./jquery_scripts/*.js')
        .pipe(babel({
            "presets": ["env"]
        }))
        .pipe(concat('scripts.js'))
        .pipe(gulpfile.dest('./public/javascript/'))
}

gulpfile.task('default', gulpfile.series(less_to_css, scripts));