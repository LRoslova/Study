var express = require('express');
var router = express.Router();
var galary = require('./JSON/auction.json');
var bodyParser = require('body-parser');
const fs = require('fs');
var person = require('./JSON/members.json')
var settings = require('./JSON/settings.json')


router.get('/', (req, res)=>{
    res.render('index');
});

router.get('/auction_list', (req, res, next) => {
    res.render("auction_list.pug", {img_list: galary});
    next();
});

router.get('/add_lot', (req, res,next)=>{
    let new_lot = {
        "id": `${galary.length+1}`,
        "title": req.query.title,
        "author": req.query.author,
        "path": req.query.path,
        "min_step": req.query.min_step,
        "max_step": req.query.max_step,
        "info": req.query.info,
        "price": req.query.price,
        "year": req.query.year
    };
    galary.push(new_lot);
    fs.writeFileSync("./JSON/auction.json", JSON.stringify(galary, null, 2));
    res.end(JSON.stringify(new_lot));
    next();
})

router.get('/delete_lot', (req, res,next)=>{
    let id = req.query.id_del;
    for(item of galary){
        if(item.id === id){
            galary.splice(id-1, 1);
        }
    }
    let n=1;
    for(item of galary){
        item.id = `${n}`;
        n+=1;
    }
    fs.writeFileSync("./JSON/auction.json", JSON.stringify(galary, null, 2));
    res.end(id);
    //res.redirect('/auction_list');
    next();
})

router.get('/lot/:num', (req, res, next) => {
    id = req.params.num;
    res.render("lot.pug", {lot: galary[id-1]});
    next();
});

router.post('/edit_lot/:num', (req, res, next) => {
    let id = req.params.num;
    for (item of galary){
        if(item.id === id){
            item.title = req.body.title;
            item.author = req.body.author;
            item.info = req.body.info;
            item.min_step = req.body.min_step;
            item.max_step = req.body.max_step;
            item.price = req.body.price;
            item.year = req.body.year;
            console.log(req.body.year)
            break;
        }
    }
    fs.writeFileSync("./JSON/auction.json", JSON.stringify(galary, null, 2));
    res.redirect(`/lot/`+id);
    next();

});

router.get('/members', (req, res, next) => {
    res.render("members.pug", {members: person});
    next();
});

router.get('/add_person', (req, res,next)=>{
    let new_person= {
        "id": `${person.length+1}`,
        "name": req.query.name,
        "money": req.query.money
    };
    person.push(new_person);
    fs.writeFileSync("./JSON/members.json", JSON.stringify(person, null, 2));
    res.end(JSON.stringify(new_person));
    next();
})

router.get('/delete_person', (req, res)=>{
    let id = req.query.id_pers;
    for(item of person){
        if(item.id === id){
            person.splice(id-1, 1);
        }
    }

    let n=1;
    for(item of person){
        item.id = `${n}`;
        n+=1;
    }

    fs.writeFileSync("./JSON/members.json", JSON.stringify(person, null, 2));
    res.end(id);
    //res.redirect('/auction_list');
})

router.post('/edit_money', (req, res, next) => {

    for (item of person){
        if(item.id === req.body.id){
            item.money = req.body.new_money;
            break;
        }
    }
    fs.writeFileSync("./JSON/members.json", JSON.stringify(person, null, 2));
    res.redirect('/members');
    next();

});

router.get('/settings', (req, res, next) => {
    res.render("settings.pug", {settings: settings});
    next();
});

router.get('/set_settings', (req, res, next) => {
    let new_settings={
        "date_s": req.query.date_s,
        "time_s": req.query.time_s,
        "timeout": req.query.timeout,
        "pause": req.query.pause,
        "torg": req.query.torg
    }
    fs.writeFileSync("./JSON/settings.json", JSON.stringify(new_settings, null, 2));
    res.end(JSON.stringify(new_settings));
    next();
});

module.exports = router;