"use strict";

$(document).ready(function () {
  $("#button_addLot").click(function () {
    $("#add_lot").show();
    $('#form_del').css('margin-top', '-390px');
  });
  $('#close').click(function () {
    $('#add_lot').hide();
    $('#form_del').css('margin-top', '0');
  });
  $("#add").click(function () {
    $('#add_lot').hide();
    $('#form_del').css('margin-top', '0');
    $.get('/add_lot', {
      path: $("#url").val(),
      title: $("#title").val(),
      author: $("#author").val(),
      info: $("#info").val(),
      min_step: $("#min_step").val(),
      max_step: $("#max_step").val(),
      price: $("#price").val(),
      year: $("#year").val()
    }).done(function (data) {
      var lot = JSON.parse(data);
      $('table').append("<tr id = " + lot.id + ">\n                    <td>" + lot.id + "</td>\n                    <td> <img src=" + lot.path + " alt=\"no work\"> </td>\n                    <td>" + lot.title + "</td></tr>");
    });
  });
  $("#del_but").click(function () {
    $("#form_del").show();
  });
  $('#exit').click(function () {
    $('#form_del').hide();
  });
  $("#delete_lot").click(function () {
    $('#form_del').hide();
    $.get('/delete_lot', {
      id_del: $("#title_del").val()
    }).done(function (data) {
      console.log(data); //let id = data;

      $("#" + data).remove();
    });
  });
});
"use strict";

$(document).ready(function () {
  $("#openForm").click(function () {
    $("#edit_lot").show();
  });
  $('#close').click(function () {
    $('#edit_lot').hide();
  });
  $("#save").click(function () {
    $('#edit_lot').hide();
  });
});
"use strict";

$(document).ready(function () {
  $("#button_addPerson").click(function () {
    $("#add_person").show();
    $('#form_delPerson').css('margin-top', '-228px');
  });
  $('#close').click(function () {
    $('#add_person').hide();
    $('#form_delPerson').css('margin-top', '0');
  });
  $("#add_newMember").click(function () {
    $('#add_person').hide();
    $('#form_delPerson').css('margin-top', '0');
    $.get('/add_person', {
      name: $("#name").val(),
      money: $("#money").val()
    }).done(function (data) {
      var person = JSON.parse(data);
      $('table').append("<tr id = " + person.id + ">\n                    <td>" + person.id + "</td>\n                    <td>" + person.name + "</td>\n                    <td>" + person.money + "</td></tr>");
    });
  });
  $("#del_pers").click(function () {
    $("#form_delPerson").show();
  });
  $('#exit').click(function () {
    $('#form_delPerson').hide();
  });
  $("#delete_pers").click(function () {
    $('#form_delPerson').hide();
    $.get('/delete_person', {
      id_pers: $("#person_del").val()
    }).done(function (data) {
      console.log(data);
      $("#" + data).remove();
    });
  });
  $("#open_money").click(function () {
    $("#edit_money").show();
  });
  $('#closeMoney').click(function () {
    $('#edit_money').hide();
  });
});
"use strict";

$(document).ready(function () {
  $("#button_settings").click(function () {
    $.get('/set_settings', {
      date_s: $("#date_s").val(),
      time_s: $("#time_s").val(),
      timeout: $("#timeout").val(),
      pause: $("#pause").val(),
      torg: $("#torg").val()
    }).done(function (data) {
      var set = JSON.parse(data);
      $('#date_s').val(set.date_s);
      $('#time_s').val(set.time_s);
      $('#timeout').val(set.timeout);
      $('#pause').val(set.pause);
      $('#torg').val(set.torg);
    });
  });
  $("#del_pers").click(function () {
    $("#form_delPerson").show();
  });
  $('#exit').click(function () {
    $('#form_delPerson').hide();
  });
  $("#delete_pers").click(function () {
    $('#form_delPerson').hide();
    $.get('/delete_person', {
      id_pers: $("#person_del").val()
    }).done(function (data) {
      console.log(data);
      $("#" + data).remove();
    });
  });
  $("#open_money").click(function () {
    $("#edit_money").show();
  });
  $('#closeMoney').click(function () {
    $('#edit_money').hide();
  });
});