var express = require('express');
var router = express.Router();
var library = require('./book.json');
var bodyParser = require('body-parser');


router.get('/', (req, res)=>{
    res.render('index');
});

router.get('/library', (req, res, next) => {
    res.render("library.pug", {books: library});
    next();
});

router.get('/filter/:num', (req, res, next) => {
    const id = req.params.num;
    if(id === "all"){
        let array = [];
        for(item of library){
            array.push(item.id);
        }
        res.end(JSON.stringify(array));
        return;
    }
    else if(id ==="returnDate"){
        let array = [];
        let todayDate = new Date();
        for(item of library){
            let itemDate = new Date(item.date_return+"T23:59:59.999Z");
            if(item.availability === "Есть в наличии" || itemDate > todayDate) {
                array.push(item.id)
            }
        }
        res.end(JSON.stringify(array));
        return;
    }
    else if(id ==="avail"){
        let array = [];
        for(item of library){
            if(item.availability === "Нет в наличии") {
                array.push(item.id);
            }
        }
        res.end(JSON.stringify(array));
        return;
    }
    next();
});

router.get('/book/:num', (req, res, next) => {
    const id = req.params.num;
    for(let value of library) {
        if (value.id === id) {
            res.render('book.pug', {book: value})
        }
    }
    next();
});

router.post('/lib_edit', (req, res, next) => {
    let last_id;
    if(library.length === 0){
        last_id = 1;
    }
    else{
        last_id = library.length+1;
    }

    library.splice(last_id-1, 0, {
        "id": `${last_id}`,
        "title": req.body.title,
        "author": req.body.author,
        "year": req.body.year,
        "availability": "Есть в наличии",
        "return_date": "-",
        "person": "-"
    });
    res.redirect('/library');
    next();
});

router.post("/book/delete/:num", (req, res, next) => {
    let id = req.params.num;
    for(item of library){
        if(item.id === id){
            library.splice(id-1, 1);
        }
    }
    let n=1;
    for(item of library){
        item.id = `${n}`;
        n+=1;
    }
    res.redirect('/library');
    next();
});

router.post("/book/edit/:num", (req, res, next) => {
    let id = req.params.num;
    for (item of library) {
        if (item.id === id) {
            item.title = req.body.title;
            item.author = req.body.author;
            item.year = req.body.year;
        }
    }
    res.redirect(`/book/${id}`);
    next();
});

router.post('/book/return/:num', (req, res, next) => {
    const id = req.params.num;
    for (item of library) {
        if (item.id === id) {
            item.name = "-";
            item.date_return = "-";
            item.availability = "Есть в наличии";
        }
    }
    res.redirect(`/book/${id}`);
    next();
});

router.post('/book/get/:num', (req, res, next) => {
    const id = req.params.num;
    for (item of library) {
        if (item.id === id) {
            item.name = req.body.person ;
            item.date_return = req.body.return_date;
            item.availability = "Нет в наличии";
        }
    }
    res.redirect(`/book/${id}`);
    next();
});

module.exports = router;