const express = require('express');
const app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));
//позволяет генерировать абс.пути для передачи стат.файлов
const path = require('path');
//подключаем маршруты
let route = require('./route');
//Указываем механизм визуализации
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

app.use('/public', express.static('public'));
app.use('/', route);
app.use(express.static(__dirname));

app.listen(3000, ()=>{
    console.log("Server started at browser http://localhost:3000");
});
