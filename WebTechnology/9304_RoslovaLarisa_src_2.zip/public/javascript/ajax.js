function getAjax(id, callback){
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function (){
        if (this.readyState == 4 && this.status == 200){
            callback(this.responseText);
        }
    }
    xhttp.open("get", `/filter/${id}`, true)
    xhttp.send();
}

function book_filter(button){
    let id = button.id;
    getAjax(id, (response)=>{
        let array = JSON.parse(response);
        for(id of array) {
            let cur = document.getElementById(id);
            cur.style.display = "none";
        }
    });
}
function allBook(button){
    let id = button.id;
    getAjax(id, (response)=>{
        let array = JSON.parse(response);
        for(id of array) {
            let cur = document.getElementById(id);
            cur.style.display = "table-row";
        }
    });
}