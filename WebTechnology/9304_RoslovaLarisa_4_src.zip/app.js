const express = require('express');
const app = express();
var bodyParser = require('body-parser');
var fs = require('fs');
var https = require('https');

const settings = require('./JSON/settings.json');
const galary = require('./JSON/auction.json');
const persons = require('./JSON/members.json');

httpsOptions ={
  key: fs.readFileSync('./key/server.key'),
  cert: fs.readFileSync('./key/server.crt')
}

let server = https.createServer(httpsOptions, app);
const SocketIO = require('socket.io');
const io = SocketIO(server);

app.use(bodyParser.urlencoded({extended: true}));
//позволяет генерировать абс.пути для передачи стат.файлов
const path = require('path');
//подключаем маршруты
let route = require('./route');
const {use} = require("express/lib/router");
//Указываем механизм визуализации
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

app.use('/public', express.static('public'));
app.use('/JSON', express.static('JSON'));
app.use('/jquery_scripts', express.static('jquery'));
app.use('/jquery-ui-1.13.0.custom', express.static('jquery-ui-1.13.0.custom'));
app.use('/', route);
app.use(express.static(__dirname));
var time_id;
var i = 0;
let last_rate = undefined;
let price = undefined;
let id_lot = undefined;
let user_id = undefined


io.on('connect', (socket) => {
    console.log('New user connected');
    socket.on('new_connect', data => {
        io.emit('push_name_chat', {time: current_time(), message: data.name});
    });

    //сокет старта аукциона
    socket.on('start_auction', () => {
        io.emit('start_message', {message: 'Аукцион начинается!', time: current_time()});
        new_torg();
        time_id = setInterval(new_torg, 40000); //время, уделяемое одному лоту

        function new_torg(){
            if(last_rate){
                io.emit('buyer', {name: last_rate, price: price, id: id_lot, user: user_id, picture: galary[id_lot-1]})
                last_rate = undefined;
                price = undefined;
                id_lot = undefined;
                user_id = undefined;
            }
            if(i === galary.length){
                clearInterval(time_id); //когда лоты закончатся, аукцион остановится
                io.emit('finish', {time: current_time()})
                i = 0;
                return;
            }
            io.emit('new_lot', {item: galary[i++]})

        }
        console.log('hi without torg')
    });

    //сокет для старта торгов (оповещение участников)
    socket.on('start_torg', ()=>{
        socket.emit('timer_torg', {x: 25, time: current_time(), message: 'Начинаем торг! Успейте предложить свою цену!'});
    })

    //сокет для получения минимального шага ставок
    socket.on('get_min_step', (data)=>{
        let id = Number(data.id);
        let min_step = galary[id-1].min_step;
        socket.emit('send_min', {min: min_step});
    })

    //сокет для обработки ставки + запоминает участника, сделавшего ставку последним
    socket.on('add_rate', (data)=>{
        user_id = data.user_id;
        id_lot = data.id;
        price = data.rate;
        last_rate = data.name;
        io.emit('set_rate', {rate: price, name: last_rate, time: current_time()});
    })

    // когда клиент и сервер отсоединились
    socket.on('disconnect', ()=>{
      console.log('disconnected from user');
    });
});


function current_time(){
    let now_time = new Date();
    let cur_time = `${now_time.getHours()}:${now_time.getMinutes()}`;
    return cur_time;
}
server.listen(3000, ()=>{
  console.log("Server started at https://localhost:3000");
});