var express = require('express');
var router = express.Router();
var galary = require('./JSON/auction.json');
var bodyParser = require('body-parser');
const fs = require('fs');
var persons = require('./JSON/members.json')
var settings = require('./JSON/settings.json')


router.get('/', (req, res)=>{
    res.render('index');
});

router.post('/auction', (req, res, next) => {
    let person_name = req.body.user_name;
    if(person_name === 'Admin'){
        res.render("admin_page.pug", {members: persons, img_list: galary});
    }
    for(let item of persons){
        if(item.name === person_name){
            res.render('user_page.pug', {user: item});
        }
    }
    next();
});
module.exports = router;