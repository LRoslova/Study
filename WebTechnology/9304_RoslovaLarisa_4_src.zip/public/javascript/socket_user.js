const socket = io();
// соединение с сервером
socket.on('connect', () => {
    let member_name = $('#user_name').text();
    socket.emit('new_connect', { name : member_name });
});
socket.on('push_name_chat', function(data) {
    $('#chat').append(`<p>[${data.time}] ${data.message}: присоединился к аукциону!`);
});

socket.on('start_message', (data)=>{
    $('#chat').append(`<p>[${data.time}] ${data.message}`);
})

//выводим новый лот
socket.on('new_lot', (data)=>{
        $('#id_lota').text(`${data.item.id}`);
        $('#image_p').attr('src', `${data.item.path}`);
        $('#title').text(`${data.item.title}`);
        $('#author_img').text(`${data.item.author}`);
        $('#year_img').text(`${data.item.year}`);
        $('#inform_image').text(`${data.item.info}`);
        $('#start_price').text(`${data.item.price}`);
        $('#cur_price').text(`none`);

        $('#new_price').hide();
        $('#rate').hide();
        $('#send_rate').hide();
        $('#err').hide();

        let timer; // пока пустая переменная
        let x =10; // стартовое значение обратного отсчета
        countdown(); // вызов функции
        function countdown(){  // функция обратного отсчета
            $('#timer').text(`На изучение лота осталось: ${x} сек!`)
            x--; // уменьшаем число на единицу
            if (x<0){
                clearTimeout(timer); // таймер остановится на нуле
                socket.emit('start_torg');
            }
            else {
                timer = setTimeout(countdown, 1000);
            }
        }
})

//таймер торгов
socket.on('timer_torg', (data)=>{
    $('#chat').append(`<p>[${data.time}] ${data.message}`);
    $('#new_price').show();
    let timer;
    let x = data.x;
    countdown(); // вызов функции
    function countdown(){  // функция обратного отсчета
        $('#timer').text(`На торг осталось: ${x} сек!`)
        x--; // уменьшаем число на единицу
        if (x<0){
            clearTimeout(timer); // таймер остановится на нуле
            $('#new_price').hide();
            $('#new_price').hide();
            $('#rate').hide();
            $('#send_rate').hide();
        }
        else {
            timer = setTimeout(countdown, 1000);
        }
    }
})

//тут подсчитываем минимальную ставку, которую может сделать участник
// (текущая стоимость + минимальный шаг)
socket.on('send_min', (data)=>{
    let min_step = Number(data.min);
    $('#new_price').hide();
    $('#rate').show();
    $('#send_rate').show();
    let value = $('#cur_price').text();
    if(value === 'none'){
        let new_price = $('#start_price').text();
        new_price = Number(new_price);
        new_price = new_price + min_step;
        $('#rate').val(new_price);
    }else{
        let new_price = Number(value);
        new_price = new_price + min_step;
        $('#rate').val(new_price);
    }
})

//оповещение в чат о новой ставке
socket.on('set_rate', (data)=>{
    $('#cur_price').text(`${data.rate}`);
    $('#chat').append(`<p>[${data.time}] ${data.name}: сделал ставку в ${data.rate}!`);
})

//покупка картины и подсчёт бюджета
// обновление листа покупок
socket.on('buyer', (data)=>{
    $('#chat').append(`<p> ${data.name} получает картину за ${data.price}`);
    $(`#${data.id}_customer`).text(`Продана: ${data.name}`);
    $(`#${data.id}_price_of_buy`).text(`Продана за: ${data.price}`);
    let money = $(`#balance_${data.user}`).text()
    money = Number(money);
    let sub = Number(data.price);
    money = money-sub;
    $(`#balance_${data.user}`).text(money);
    money = $(`#${data.user}_money`).text()
    money = Number(money);
    money = money - sub;
    $(`#${data.user}_money`).text(money);
    $(`#lot_buy_${data.user}`).append(`<tr> <td><img src="${data.picture.path}"></td> <td>${data.picture.title}</td> </tr>`);

})

socket.on('finish', (data)=>{
    $('#chat').append(`<p> ${data.time} Аукцион завершился! Спасибо за участие.`);
})

function auction_on(){
    socket.emit('start_auction');
    $('#start_auction').hide();
}

function open_rate(){
    let id_lot = $('#id_lota').text();
    socket.emit('get_min_step', {id: id_lot})
}

function add_rate(){
    let id = $('#id_lota').text();
    let rate = $('#rate').val();
    let member_id = $('#user_id').text();
    rate = Number(rate)
    let cur_price = $('#cur_price').text();
    cur_price = Number(cur_price);
    let balance = $(`#balance_${member_id}`).text();
    balance = Number(balance);
    if(rate<=cur_price){
        $('#err').show();
        $('#err').text('Некорректная ставка!');
        return;
    }
    if(rate>balance){
        $('#err').show();
        $('#err').text('Ставка превышает ваш баланс!');
        return;
    }
    let member_name = $('#user_name').text();
    socket.emit('add_rate', {rate: rate, name: member_name, id: id, user_id: member_id})
    $('#new_price').show();
    $('#rate').hide();
    $('#send_rate').hide();
}

// when disconnected from server
socket.on('disconnect', function(){
    console.log('Disconnect from server')
});