$(document).ready(function() {
    $('#dialog_form').draggable();
});

