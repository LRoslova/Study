$(document).ready(function() {
    $('#dialog_form').draggable();
    $('#new_price').hide();
    $('#rate').hide();
    $('#send_rate').hide();
    $('#err').hide();
    $("#tabs").tabs();

});