let gameManager = {
    factory: {},
    entities: [],
    fireNum: 0,
    player: null,
    laterKill: [],
    rAF: null,
    interval:false,
    initPlayer: (obj)=> {
        gameManager.player = obj;
    },
    kill: (obj)=> {
        gameManager.laterKill.push(obj);
    },
    update: ()=> {
        if(gameManager.player === null)
            return;
        gameManager.player.move_x = 0;
        gameManager.player.move_y = 0;
        Player.flag = '';
        console.log(gameManager.player.lifetime)
        if (eventsManager.action["up"]) {
            gameManager.player.move_y = -1;
            Player.flag = 'up';
        }
        if (eventsManager.action["down"]) {
            gameManager.player.move_y = 1;
            Player.flag = 'down';
        }
        if (eventsManager.action["left"]) {
            gameManager.player.move_x = -1;
            Player.flag = 'left';
        }
        if (eventsManager.action["right"]) {
            gameManager.player.move_x = 1;
            Player.flag = 'right';
        };

        if(gameManager.player.move_x !== 0 || gameManager.player.move_y !== 0){
            gameManager.player.fire_y = gameManager.player.move_y;
            gameManager.player.fire_x = gameManager.player.move_x;
        }
        if(gameManager.player.lifetime <= 0) {
            gameManager.player.kill();
        };
        let health_on_window = document.getElementById('progress');
        health_on_window.value = gameManager.player.lifetime;
        let score_on_window = document.getElementById('score');
        score_on_window.innerHTML = `Счёт: ${gameManager.score}`;

        if (eventsManager.action["fire"]){
            gameManager.player.fire();
            Skeleton.fire();
        }
        gameManager.entities.forEach(function(e) {
            try {
                e.update();
            } catch(ex) {}
        });
        for(let i = 0; i < gameManager.laterKill.length; i++) {
            let idx = gameManager.entities.indexOf(gameManager.laterKill[i]);
            if(idx > -1)
                gameManager.entities.splice(idx, 1);
        }
        if(gameManager.laterKill.length > 0)
            gameManager.laterKill.length = 0;
        mapManager.draw(ctx);
        mapManager.centerAt(gameManager.player.pos_x, gameManager.player.pos_y);
        gameManager.draw(ctx);
    },
    draw: function (ctx) {
        for(let e = 0; e < gameManager.entities.length; e++) {
            gameManager.entities[e].draw(ctx);
        }
    },
    loadAll: (map)=> {
        soundManager.init();
        soundManager.loadArray(['public/sound/bottle-pouring.mp3','public/sound/carrot_chew_munch_001_28556.mp3', 'public/sound/zvuk-poleta-ognennogo-shara.mp3']);
        mapManager.loadMap(map);
        spriteManager.loadAtlas("public/map/atlas.json", "public/map/spritesheet.png");
        gameManager.factory['player'] = Player;
        gameManager.factory['enemy'] = Skeleton;
        gameManager.factory['buff'] = Buff;
        gameManager.factory['debuff'] = Debuff;
        gameManager.factory['portal'] = Portal;
        gameManager.factory['fireball'] = Fireball;
        let name_on_window = document.getElementById('name');
        let user_name = localStorage.getItem("game.username");
        name_on_window.innerHTML = name_on_window.innerHTML + user_name;
        mapManager.draw(ctx);
        eventsManager.setup(canvas);
    },
    play: ()=> {
        //updateRecordTable();
        const startButton = document.getElementById('startGame');
        startButton.style.display = 'none';
        gameManager.score = 0;
        gameManager.loadAll("public/json/level_1.json");
        Player.lifetime = 100;
        gameManager.interval = setInterval(gameManager.updateWorld,10)

    },
    updateWorld:()=>{
        gameManager.update();
    },

};
