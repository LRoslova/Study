let canvas = document.getElementById('canvas_id');
const ctx = canvas.getContext('2d');

let mapManager = {
    mapData: null,
    tLayer: [],
    xCount: 0,
    yCount: 0,
    tSize: {x: 32, y: 32},
    mapSize: {x: 30, y: 18},
    tilesets: [],
    imgLoadCount: 0,
    imgLoaded: false,
    jsonLoaded: false,
    view: {x: 0, y: 0, w: 992, h: 608},
    next_level: '',
    score: 0,

    loadMap: (path)=>{
        let request = new XMLHttpRequest();
        request.onreadystatechange = ()=>{
            if(request.readyState === 4 && request.status === 200){
                mapManager.parseMap(request.responseText)
            }
        }
        request.open('GET',path,true);
        request.send();
    },

    parseMap: (tilesJSON)=>{
        mapManager.tLayer = [];
        mapManager.mapData = JSON.parse(tilesJSON);
        mapManager.xCount = mapManager.mapData.width;
        mapManager.yCount = mapManager.mapData.height;
        mapManager.tSize.x = mapManager.mapData.tilewidth;
        mapManager.tSize.y = mapManager.mapData.tileheight;
        mapManager.mapSize.x = mapManager.xCount * mapManager.tSize.x;
        mapManager.mapSize.y = mapManager.yCount * mapManager.tSize.y;
        mapManager.next_level = mapManager.mapData.nextLevel;
        mapManager.score = mapManager.mapData.score;

        for (let i = 0; i < mapManager.mapData.tilesets.length; i++) {
            let img = new Image();
            img.onload = function () {
                mapManager.imgLoadCount++;
                if (mapManager.imgLoadCount === mapManager.mapData.tilesets.length) {
                    mapManager.imgLoaded = true;
                }
            };
            img.src = mapManager.mapData.tilesets[i].image;
            let t = mapManager.mapData.tilesets[i];
            let ts = {
                firstgid: t.firstgid,
                image: img,
                name: t.name,
                xCount: Math.floor(t.imagewidth / mapManager.tSize.x),
                yCount: Math.floor(t.imageheight / mapManager.tSize.y)
            };
            mapManager.tilesets.push(ts);
        }
        mapManager.jsonLoaded = true;
        mapManager.parseEntities();
    },
    draw: (ctx)=>{
        if (!mapManager.imgLoaded || !mapManager.jsonLoaded) {
            setTimeout(function () {
                mapManager.draw(ctx);
            }, 100);
        } else {
            if (mapManager.tLayer.length === 0) {
                for (let id = 0; id < mapManager.mapData.layers.length; id++) {
                    let layer = mapManager.mapData.layers[id];
                    if (layer.type === "tilelayer") {
                        mapManager.tLayer.push(layer);
                        //break;
                    }
                }
            }
            for(let j = 0; j < mapManager.tLayer.length; ++j) {
                for (let i = 0; i < mapManager.tLayer[j].data.length; i++) {
                    if (mapManager.tLayer[j].data[i] !== 0) {
                        let tile = mapManager.getTile(mapManager.tLayer[j].data[i]);
                        let pX = (i % mapManager.xCount) * mapManager.tSize.x;
                        let pY = Math.floor(i / mapManager.xCount) * mapManager.tSize.y;
                        if (!mapManager.isVisible(pX, pY, mapManager.tSize.x, mapManager.tSize.y))
                            continue;
                       // pX -= mapManager.view.x;
                       // pY -= mapManager.view.y;
                        ctx.drawImage(tile.img, tile.px, tile.py, mapManager.tSize.x, mapManager.tSize.y, pX, pY, mapManager.tSize.x, mapManager.tSize.y);
                    }
                }
            }
        }
    },
    isVisible: (x, y, width, height)=>{
        if(x + width < mapManager.view.x || y + height < mapManager.view.y || x > mapManager.view.x + mapManager.view.w || y > mapManager.view.y + mapManager.view.h)
            return false;
        return true;
    },
    getTile: (tileIndex)=>{
        let tile = {
            img: null,
            px: 0, py: 0
        };
        let tileset = mapManager.getTileset(tileIndex);
        tile.img = tileset.image;
        let id = tileIndex - tileset.firstgid;
        let x = id % tileset.xCount;
        let y = Math.floor(id / tileset.xCount);
        tile.px = x * mapManager.tSize.x;
        tile.py = y * mapManager.tSize.y;
        return tile;
    },
    getTileset: (tileIndex)=>{
        for (let i = mapManager.tilesets.length - 1; i >= 0; i--)
            if (mapManager.tilesets[i].firstgid <= tileIndex) {
                return mapManager.tilesets[i];
            }
        return null;
    },
    parseEntities: ()=>{
        gameManager.entities = [];
        if (!mapManager.imgLoaded || !mapManager.jsonLoaded) {
            setTimeout(function () { mapManager.parseEntities(); }, 100);
        } else
            for (let j = 0; j < mapManager.mapData.layers.length; j++) {
                if (mapManager.mapData.layers[j].type === 'objectgroup') {
                    let entities = mapManager.mapData.layers[j];
                    for (let i = 0; i < entities.objects.length; i++) {
                        let e = entities.objects[i];
                        try {
                            let obj = Object.create(gameManager.factory[e.type]);
                            obj.name = e.name;
                            obj.pos_x = e.x;
                            obj.pos_y = e.y;
                            obj.size_x = e.width;
                            obj.size_y = e.height;
                            gameManager.entities.push(obj);
                            if (obj.name === "player") {
                                gameManager.initPlayer(obj);
                            }
                        } catch (ex) {
                            console.log("Error while creating: [" + e.gid + "] " + e.type + ", " + ex);
                        }
                    }
                }
            }
    },
    getTilesetIdx: (x, y, layerLevel) => {
        let idx = Math.floor(y / mapManager.tSize.y) * mapManager.xCount + Math.floor(x / mapManager.tSize.x);
        let layer = mapManager.tLayer[layerLevel];
        return layer.data[idx];
    },

    centerAt: (x, y)=>{
        if(x < mapManager.view.w / 2){
            mapManager.view.x = 0;
        }
        else
        if(x > mapManager.mapSize.x - mapManager.view.w / 2)
            mapManager.view.x = mapManager.mapSize.x - mapManager.view.w;
        else
            mapManager.view.x = x - (mapManager.view.w / 2);
        if(y < mapManager.view.h / 2) {
            mapManager.view.y = 0;
        }
        else
        if(y > mapManager.mapSize.y - mapManager.view.h / 2) {
            mapManager.view.y = mapManager.mapSize.y - mapManager.view.h;
        }
        else
            mapManager.view.y = y - (mapManager.view.h / 2);
    },
    gameOver: function (){
        clearInterval(gameManager.interval);
        const startButton = document.getElementById('startGame');
        startButton.disabled = false;
        setTimeout(()=>{
            ctx.fillStyle = 'darkblue';
            ctx.globalAlpha = 0.6;
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.globalAlpha = 1;
            ctx.fillStyle = 'white';
            ctx.font = '35px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('Конец игры!', canvas.width / 2, canvas.height / 2);

        }, 200);
        addRecord();
        updateRecordTable();

    }


}

//mapManager.loadMap("public/json/level_1.json");
//mapManager.parseEntities();
//mapManager.draw(ctx);

