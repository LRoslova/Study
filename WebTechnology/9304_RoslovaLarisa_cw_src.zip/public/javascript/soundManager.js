let soundManager = {
    clips: {},
    context: null,
    gainNode: null,
    loaded: false,

    init: ()=>{
        soundManager.context = new AudioContext();
        soundManager.gainNode = soundManager.context.createGain ? soundManager.context.createGain() : soundManager.context.createGainNode();
        soundManager.gainNode.connect(soundManager.context.destination);
    },
    load: (path, callback)=>{
        if(soundManager.clips[path]){
            callback(soundManager.clips[path]);
            return;
        }
        let clip = {path: path, buffer: null, loaded: false};
        clip.play = (volume, loop)=>{
            soundManager.play(soundManager.path, {looping: loop ? loop : false, volume: volume ? volume : 1});
        };
        soundManager.clips[path] = clip;
        let request = new XMLHttpRequest();
        request.open('GET', path, true);
        request.responseType = 'arraybuffer';
        request.onload = () => {
            soundManager.context.decodeAudioData(request.response, (buffer)=>{
                clip.buffer = buffer;
                clip.loaded = true;
                callback(clip);
            });
        };
        request.send();
    },
    loadArray: (array)=>{
        for(let i = 0; i < array.length; i++){
            soundManager.load(array[i], ()=>{
                if(array.length === Object.keys(soundManager.clips).length){
                    for(let sd in soundManager.clips){
                        if(!soundManager.clips[sd].loaded){
                            return;
                        }
                    }
                    soundManager.loaded = true;
                }
            });
        }
    },
    setVolume: (val) => {
        soundManager.gainNode.gain.value = val;
    },
    play: (path, settings)=>{
        if(!soundManager.loaded){
            setTimeout(()=>{
                soundManager.play(path, settings);
            }, 1000);
            return;
        }
        let looping = false;
        let volume = 0.3;
        if(settings){
            if(settings.looping){
                looping = settings.looping;
            }
            if(settings.volume){
                volume= settings.volume;
            }
        }
        let sd = soundManager.clips[path];
        if(sd === null){
            return false;
        }
        let sound = soundManager.context.createBufferSource();
        sound.buffer = sd.buffer;
        sound.connect(soundManager.gainNode);
        sound.loop = looping;
        soundManager.gainNode.gain.value = volume;
        sound.start(0);
        return true;
    }
}