
let eventsManager = {
    bind: [],   // сопоставление клавиш действиям
    action: [], //действия
    setup: (canvas)=>{              // настройка сопоставления
        eventsManager.bind[87] = 'up';       // w - двигаться вверх
        eventsManager.bind[65] = 'left';     // a - двигаться влево
        eventsManager.bind[83] = 'down';     // s - двигаться вниз
        eventsManager.bind[68] = 'right';    // d - двигаться вправо
        eventsManager.bind[69] = 'use';      // e - взаимодействие
        eventsManager.bind[32] = 'fire';     // пробел - выстрелить
        // контроль событий «мыши»
        canvas.addEventListener("mousedown", eventsManager.onMouseDown);
        canvas.addEventListener("mouseup", eventsManager.onMouseUp);
        // контроль событий клавиатуры
        document.body.addEventListener("keydown", eventsManager.onKeyDown);
        document.body.addEventListener("keyup", eventsManager.onKeyUp);
    },
    onMouseDown: (event)=>{ // нажатие на клавишу «мыши»
        eventsManager.action["fire"] = true;
    },
    onMouseUp: (event)=>{// отпустили клавишу «мыши»
        eventsManager.action["fire"] = false;
    },
    onKeyDown: (event)=>{ // нажали на кнопку
        // на клавиатуре, проверили, есть ли сопоставление действию для события с кодом keyCode
        let action = eventsManager.bind[event.keyCode];
        if (action) // проверка на action === true
            eventsManager.action[action] = true; // согласились выполнять действие
    },
    onKeyUp: (event)=>{ // отпустили кнопку на клавиатуре
        // проверили, есть ли сопоставление действию для события
        // с кодом keyCode
        let action = eventsManager.bind[event.keyCode]; // проверили
        // наличие действия
        if (action) // проверка на action === true
            eventsManager.action[action] = false; // отменили действие
    }
};