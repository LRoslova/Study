function check_name(el){
    let user = el.user_name.value;
    let fail = "";

    if(user =="")
        fail = "Заполните поле с именем!";
    else if(user.length <=1 || user.length > 50)
        fail = "Введите значение в пределах от 1 до 50 символов!";

    if(fail != ""){
        document.getElementById('error').innerHTML = fail;
        return false;
    } else{
        localStorage["game.username"] = user;
        window.location = 'https://localhost:3000/game';
        return false;
    }
}

function addRecord(){
    let user_name = localStorage.getItem("game.username");
    let tmp = localStorage.getItem(user_name);
    if(tmp){
        if(gameManager.score > tmp){
            localStorage.removeItem(user_name);
            localStorage.setItem(user_name, gameManager.score);
        }
    }else{
        localStorage.setItem(user_name, gameManager.score);
    }
}

function updateRecordTable(){

    localStorage.removeItem("game.username");
    let record = [];
    for(let i = 0; i < localStorage.length; i++) {
        let key = localStorage.key(i);
        record.push([key, localStorage.getItem(key)]);
    }

    if(record.length >= 2){
        record.sort(function compareNumbers(a, b){
            return b[1] - a[1];
        });
    }

    for(let j = 0; j < 5; ++j){
        if(j > record.length - 1){
            break;
        }
        let position = document.getElementById((j + 1).toString());
        position.innerHTML = "№"+(j+1) + ' ' + record[j][0] + ' ' + record[j][1];
    }
}

updateRecordTable();