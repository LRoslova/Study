let spriteManager = {
    image: new Image(),
    sprites: [],
    imgLoaded: false,
    jsonLoaded: false,
    loadAtlas: (atlasJson, atlasImg)=> {
        let request = new XMLHttpRequest();
        request.onreadystatechange = function () {
            if (request.readyState === 4 && request.status === 200) {
                spriteManager.parseAtlas(request.responseText);
            }
        };
        request.open("GET", atlasJson, true);
        request.send();
        spriteManager.loadImg(atlasImg);
    },
    loadImg: (imgName)=> {
        spriteManager.image.onload = function () {
            spriteManager.imgLoaded = true;
        };
        spriteManager.image.src = imgName;
    },
    parseAtlas: (atlasJSON)=> {
        let atlas = JSON.parse(atlasJSON);
        for (let name in atlas.frames) {
            let frame = atlas.frames[name].frame;
            spriteManager.sprites.push({name: name, x: frame.x, y: frame.y, w: frame.w, h: frame.h});
            //console.log('img loaded')
        }
        spriteManager.jsonLoaded = true;
    },
    drawSprite: (ctx, name, x, y)=> {
        if (!spriteManager.imgLoaded || !spriteManager.jsonLoaded) {
            setTimeout(function () { spriteManager.drawSprite(ctx, name, x, y); }, 100);
        } else {
            let sprite = spriteManager.getSprite(name);
            if(!mapManager.isVisible(x, y, sprite.w, sprite.h))
                return;
            x -= mapManager.view.x;
            y -= mapManager.view.y;
            ctx.drawImage(spriteManager.image, sprite.x, sprite.y, sprite.w, sprite.h, x,
                y, sprite.w, sprite.h);
        }
    },
    getSprite(name) {
        for (let i = 0; i < spriteManager.sprites.length; i++) {
            let s = spriteManager.sprites[i];
            if (s.name === name)
                return s;
        }
        return null;
    }

}
