let Entity = {
    pos_x: 0, pos_y: 0,
    size_x: 0, size_y: 0,
    extend: function (extendProto) {
        let object = Object.create(this);
        for (let property in extendProto) {
            if (this.hasOwnProperty(property) || typeof object[property] === 'undefined') {
                object[property] = extendProto[property];
            }
        }
        return object;
    }
};
let Player = Entity.extend({
    lifetime: 100,
    move_x: 0, move_y: 0,
    speed: 1,
    fire_timeout: true,
    AnimationCounter: 0,
    flag: '',
    fire_x: 0,
    fire_y: 0,
    draw: function (ctx) {
        if(this.flag === ''){
            spriteManager.drawSprite(ctx, "player_s2", this.pos_x, this.pos_y);
        }
        if(this.flag === 'right') {
            if (this.AnimationCounter <= 25) {
                spriteManager.drawSprite(ctx, "player_d1", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 25 && this.AnimationCounter <= 50) {
                spriteManager.drawSprite(ctx, "player_d2", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 50 && this.AnimationCounter <= 75) {
                spriteManager.drawSprite(ctx, "player_d3", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 75 && this.AnimationCounter < 100) {
                spriteManager.drawSprite(ctx, "player_d3", this.pos_x, this.pos_y);
                this.AnimationCounter = 0;
            };
            this.AnimationCounter++;
        }
        if(this.flag === 'left') {
            if (this.AnimationCounter <= 25) {
                spriteManager.drawSprite(ctx, "player_a1", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 25 && this.AnimationCounter <= 50) {
                spriteManager.drawSprite(ctx, "player_a2", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 50 && this.AnimationCounter <= 75) {
                spriteManager.drawSprite(ctx, "player_a3", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 75 && this.AnimationCounter < 100) {
                spriteManager.drawSprite(ctx, "player_a3", this.pos_x, this.pos_y);
                this.AnimationCounter = 0;
            };
            this.AnimationCounter++;
        }
        if(this.flag === 'down') {
            if (this.AnimationCounter <= 25) {
                spriteManager.drawSprite(ctx, "player_s1", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 25 && this.AnimationCounter <= 50) {
                spriteManager.drawSprite(ctx, "player_s2", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 50 && this.AnimationCounter <= 75) {
                spriteManager.drawSprite(ctx, "player_s3", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 75 && this.AnimationCounter < 100) {
                spriteManager.drawSprite(ctx, "player_s3", this.pos_x, this.pos_y);
                this.AnimationCounter = 0;
            };
            this.AnimationCounter++;
        }
        if(this.flag === 'up') {
            if (this.AnimationCounter <= 25) {
                spriteManager.drawSprite(ctx, "player_w1", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 25 && this.AnimationCounter <= 50) {
                spriteManager.drawSprite(ctx, "player_w2", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 50 && this.AnimationCounter <= 75) {
                spriteManager.drawSprite(ctx, "player_w3", this.pos_x, this.pos_y);
            } else if (this.AnimationCounter > 75 && this.AnimationCounter < 100) {
                spriteManager.drawSprite(ctx, "player_w3", this.pos_x, this.pos_y);
                this.AnimationCounter = 0;
            };
            this.AnimationCounter++;
        }
        //spriteManager.drawSprite(ctx, "player_s2", this.pos_x, this.pos_y);
    },
    update: function (){ physicManager.update(this);},
    onTouchEntity: function (obj) {
        if(obj.name.match(/health[\d]/)) {
            this.lifetime += 25;
            soundManager.play('public/sound/bottle-pouring.mp3')
            console.log('Health up:', this.lifetime)
            obj.kill();
        }
        if(obj.name.match(/amanita[\d]/)) {
            this.lifetime -= 25;
            soundManager.play('public/sound/carrot_chew_munch_001_28556.mp3')
            console.log('Health up:', this.lifetime)
            obj.kill();
        }
        if(obj.name.match(/portal/)) {
            if(gameManager.score >= mapManager.score){
                if(mapManager.next_level==='false'){
                    mapManager.gameOver();
                }
                mapManager.loadMap(mapManager.next_level);
                Player.lifetime = this.lifetime;
            }
        }
    },
    kill: function (){
        gameManager.kill(this);
        mapManager.gameOver();
    },
    fire: function (){
        if(this.fire_timeout) {
            soundManager.play('public/sound/zvuk-poleta-ognennogo-shara.mp3')
            let r = Object.create(Fireball);
            this.fire_timeout = false;
            setTimeout(()=>{ this.fire_timeout = true; }, 500);
            r.size_x = 16;
            r.size_y = 16;
            r.name = "fireball" + (++gameManager.fireNum);
            r.move_x = this.fire_x;
            r.move_y = this.fire_y;
            switch (this.fire_x + 2 * this.fire_y) {
                case -1:
                    r.pos_x = this.pos_x - r.size_x;
                    r.pos_y = this.pos_y;
                    r.flag_fire = -1;
                    break;
                case 1:
                    r.pos_x = this.pos_x + this.size_x;
                    r.pos_y = this.pos_y;
                    r.flag_fire = 1;
                    break;
                case -2:
                    r.pos_x = this.pos_x;
                    r.pos_y = this.pos_y - r.size_y;
                    r.flag_fire = -2;
                    break;
                case 2:
                    r.pos_x = this.pos_x;
                    r.pos_y = this.pos_y + this.size_y;
                    r.flag_fire = 0;
                    break;
                default:
                    return;
            }
            gameManager.entities.push(r);
        }
    }
});

let Skeleton = Entity.extend({
    lifetime: 100,
    move_x: 0, move_y: 0,
    speed: 1,
    beforeMove_x: 0,
    beforeMove_y: 0,
    fire_check: true,
    draw: function (ctx){
        spriteManager.drawSprite(ctx, "enemy_s2", this.pos_x, this.pos_y);
    },
    update: function(){
        if(this.lifetime<=0){
            this.kill();
        }
        if(this.move_x === 0 && this.move_y === 0){
            const max = 1;
            const min = -1;
            this.move_x = Math.floor(Math.random() * (max - min + 1)) + min;
            this.move_y = Math.floor(Math.random() * (max - min + 1)) + min;
            this.beforeMove_x = this.move_x;
            this.beforeMove_y = this.move_y;
        }
        this.fire();
        physicManager.update(this);
    },
    onTouchMap: function(obj) {
        this.move_x = 0;
        this.move_y = 0;
    },
    onTouchEntity: function(obj) {
        if(obj.name.match(/health[\d]/)) {
            this.lifetime += 25;
            console.log('Skeleton health up:', this.lifetime)
            obj.kill();
        }
        if(obj.name.match(/amanita[\d]/)) {
            this.lifetime -= 25;
            console.log('Skeleton eat amanita, lifetime:', this.lifetime)
            obj.kill();
        }
        if(obj.name.match(/skeleton[\d]/)) {
            this.pos_x -= 2;
            this.pos_y += 2;
            obj.move_y -= 0;
            obj.move_x += 0;
            console.log('Skeleton eat amanita, lifetime:', this.lifetime)
            //obj.kill();
        }
        if(this.lifetime <=0){
            this.kill();
        }
    },
    kill: function (){
        gameManager.score +=50;
        gameManager.kill(this)
    },
    fire: function (){
        let r = Object.create(Fireball);
        r.size_x = 16;
        r.size_y = 16;
        if(Math.abs(this.pos_x - gameManager.player.pos_x) < 32){
            if((this.pos_y - gameManager.player.pos_y) > 0){
                r.pos_x = this.pos_x;
                r.pos_y = this.pos_y - r.size_y;
                r.move_y = -1;
            }else{
                r.pos_x = this.pos_x;
                r.pos_y = this.pos_y + r.size_y;
                r.move_y = 1;
            }
        }else if(Math.abs(this.pos_y - gameManager.player.pos_y) < 32){
            if((this.pos_x - gameManager.player.pos_x) > 0){
                r.pos_x = this.pos_x - r.size_x;
                r.pos_y = this.pos_y;
                r.move_x = -1;
            }else{
                r.pos_x = this.pos_x + r.size_x;
                r.pos_y = this.pos_y;
                r.move_x = 1;
            }
        }else{
            return;
        }
        if(this.fire_check){
            this.fire_check = false;
            setTimeout(()=>{ this.fire_check = true; }, 10000);
            r.name = "fireball" + (++gameManager.fireNum);
            gameManager.entities.push(r);
        }

    }
});

let Fireball = Entity.extend({
    move_x: 0, move_y: 0,
    speed: 7,
    flag_fire: 0,
    draw:  function (ctx){
        if(this.flag_fire===1){
            spriteManager.drawSprite(ctx, "fireright", this.pos_x, this.pos_y);
        }else if(this.flag_fire=== -1){
                spriteManager.drawSprite(ctx, "fireleft", this.pos_x, this.pos_y);
        }else if(this.flag_fire=== -2){
                spriteManager.drawSprite(ctx, "fireup", this.pos_x, this.pos_y);
        }else{
            spriteManager.drawSprite(ctx, "firedown", this.pos_x, this.pos_y);
        }
    },
    update: function() {physicManager.update(this); },
    onTouchEntity: function (obj) {
        if(obj.name.match(/skeleton[\d*]/)){
            obj.lifetime -=50;
        }
        if(obj.name.match(/player/)){
            obj.lifetime -=25;
        }
        if (obj.name.match(/amanita[\d*]/)|| obj.name.match(/health[\d*]/)){
            obj.kill();
        }
        if (obj.name.match(/fireball[\d*]/)){
            obj.kill();
        }
        this.kill();
    },
    onTouchMap: function(idx) { this.kill();},
    kill: function (){gameManager.kill(this) }
});

let Buff = Entity.extend({
    draw: function (ctx) {
        spriteManager.drawSprite(ctx, "buff", this.pos_x, this.pos_y);
    },
    kill: function (){gameManager.kill(this) }
});

let Debuff = Entity.extend({
    draw: function (ctx){
        spriteManager.drawSprite(ctx, "debuff", this.pos_x, this.pos_y);
    },
    kill: function (){gameManager.kill(this) }
});

let Portal = Entity.extend({
    draw: function (ctx){
        spriteManager.drawSprite(ctx, "portal", this.pos_x, this.pos_y);
    },
    kill: function (){gameManager.kill(this) }
});
