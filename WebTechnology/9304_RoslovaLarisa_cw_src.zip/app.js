const express = require('express');
const app = express();
var bodyParser = require('body-parser');
var fs = require('fs');
var https = require('https');


httpsOptions ={
    key: fs.readFileSync('./key/server.key'),
    cert: fs.readFileSync('./key/server.crt')
}

let server = https.createServer(httpsOptions, app);


app.use(bodyParser.urlencoded({extended: true}));
//позволяет генерировать абс.пути для передачи стат.файлов
const path = require('path');
//подключаем маршруты
let route = require('./route');
const {use} = require("express/lib/router");
//Указываем механизм визуализации
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

app.use('/public', express.static('public'));
app.use('/JSON', express.static('JSON'));
app.use('/', route);
app.use(express.static(__dirname));


server.listen(3000, ()=>{
    console.log("Server started at https://localhost:3000");
});