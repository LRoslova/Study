var express = require('express');
var router = express.Router();

var bodyParser = require('body-parser');



router.get('/', (req, res)=>{
    res.render('entry');
});

router.get('/game', (req, res)=>{
    res.render('game');
});



module.exports = router;