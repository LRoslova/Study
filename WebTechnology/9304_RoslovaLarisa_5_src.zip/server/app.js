const express = require('express');
const settingsRoutes = require('./routes/settings');
const cors = require('cors');
const port = 3002;
const bodyParser = require('body-parser');

const corsOptions = {
  'credentials': true,
  'origin': true,
  'methods': 'GET,HEAD,PUT,PATCH,POST,DELETE',
  'allowedHeaders': 'Authorization,X-Requested-With,X-HTTP-Method-Override,Content-Type,Cache-Control,Accept',
};

const app = express();
app.use(cors(corsOptions));
app.use('/public',express.static('public'));
app.engine('pug', require('pug').__express);
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.use('/', settingsRoutes);

app.listen(port, '127.0.0.1', () => { console.log(`Server started at http://localhost:${port}`) });