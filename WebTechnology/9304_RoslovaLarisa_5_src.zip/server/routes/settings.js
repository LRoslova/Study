const express = require('express');
const router = express.Router();
const fs = require('fs');
let brokers = require('./json/broker.json');
let shares = require('./json/share.json');

router.get('/settingsGet', (req, res, next)=>{
    let tmpjson = JSON.parse(fs.readFileSync('./routes/json/stockSettings.json'));
    res.end(JSON.stringify(tmpjson));
});

router.post('/settingsAdd',(req, res, next)=>{
    fs.writeFile("./routes/json/stockSettings.json", JSON.stringify(req.body, null, 2),(err)=>{
        if(err)
            throw err;
    });
});

router.post('/brokerAdd', (req, res, next)=>{
    fs.writeFile("./routes/json/broker.json", JSON.stringify(req.body, null, 2),function(err){
        if(err)
            throw err;
    });
});

router.get('/brokerAdd', (req, res, next)=>{
    let tmpjson = JSON.parse(fs.readFileSync('./routes/json/broker.json'));
    res.end(JSON.stringify(tmpjson));
});

router.post('/brokerChange', (req, res, next)=>{
    for(let i = 0; i < brokers.length; i++){
        if(brokers[i].id === req.body.id){
            brokers[i].first_name = req.body.first_name;
            brokers[i].last_name = req.body.last_name;
            brokers[i].money = req.body.money;
        }
    }
    fs.writeFile("./routes/json/broker.json", JSON.stringify(brokers, null, 2),function(err){
        if(err)
            throw err;
    });
});

router.post('/brokerDelete', (req, res, next)=>{
    fs.writeFile("./routes/json/broker.json", JSON.stringify(req.body, null, 2),function(err){
        if(err)
            throw err;
    });
});


// Shares

router.get('/shareGet', (req, res, next)=>{
    res.end(JSON.stringify(JSON.parse(fs.readFileSync('./routes/json/share.json'))));
});

router.post('/shareAdd',(req, res, next)=>{
    fs.writeFile("./routes/json/share.json", JSON.stringify(req.body, null, 2),(err)=>{
        if(err)
            throw err;
    });
});

router.post('/shareChange', (req, res, next)=>{
    for(let i = 0; i < shares.length; i++){
        if(shares[i].id === req.body.id){
            shares[i].name = req.body.name;
            shares[i].price = parseInt(req.body.price);
            shares[i].distribution = req.body.distribution;
            shares[i].change = parseInt(req.body.change);
            shares[i].amount = parseInt(req.body.amount);
        }
    }
    fs.writeFile("./routes/json/share.json", JSON.stringify(shares, null, 2),(err)=>{
        if(err)
            throw err;
    });
});

router.post('/shareDelete', (req, res, next)=>{
    fs.writeFile("./routes/json/share.json", JSON.stringify(req.body, null, 2),function(err){
        if(err)
            throw err;
    });
});

module.exports = router;
