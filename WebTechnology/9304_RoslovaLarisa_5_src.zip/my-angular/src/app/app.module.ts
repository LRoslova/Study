import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './ts/appComponent';
import { SettingsComponent } from "./ts/settingComponet";
import { menuComponent } from './ts/menuComponent';
import { BrokerListComponent } from './ts/brokerComponent';
import { SharesListComponent } from './ts/shareComponent';

@NgModule({
  declarations: [
    AppComponent,
    menuComponent,
    SettingsComponent,
    BrokerListComponent,
    SharesListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
