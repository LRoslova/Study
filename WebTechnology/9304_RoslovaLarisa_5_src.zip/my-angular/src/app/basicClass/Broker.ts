export class Broker {

  id: number;
  first_name: string;
  last_name: string;
  money: number;


  constructor(id: number, first_name: string, last_name: string, money: number) {
    this.id = id;
    this.first_name = first_name;
    this.last_name = last_name;
    this.money = money;
  }
}
