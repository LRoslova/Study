export class Share {

  id: number;
  name: string;
  price: number;
  distribution: string;
  change: number;
  amount: number;

  constructor(id: number, name: string, price: number, distribution: string, change: number, amount: number) {
    this.id = id;
    this.name = name;
    this.price = price;
    this.distribution = distribution;
    this.change = change;
    this.amount = amount;
  }
}
