import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { menuComponent } from "./ts/menuComponent";
import { SettingsComponent } from "./ts/settingComponet";
import { BrokerListComponent } from './ts/brokerComponent';
import { SharesListComponent } from './ts/shareComponent';

const routes: Routes = [
  { path:'', component: menuComponent },
  { path:'setting', component: SettingsComponent },
  { path:'broker', component: BrokerListComponent },
  { path:'share', component: SharesListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
