import { Component } from '@angular/core';
import { SettingsClass } from "../basicClass/Settings";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-root',
  templateUrl: '../html/setting.html',
  styleUrls: [ '../css/w3Css.css' ]
})

export class SettingsComponent {
  SettingClass = new SettingsClass('', '', '');
  tmpSettingClass = new SettingsClass('', '', '');
  constructor(public HttpClient: HttpClient) { };

  ngOnInit(){
    this.HttpClient.get("http://localhost:3002/settingsGet").subscribe((data: any)=>{
      if(Object.keys(data).length !== 0) {
        this.SettingClass = data;
      }else{
        this.SettingClass.time_start = '08:00';
        this.SettingClass.time_end = '18:00';
        this.SettingClass.intervalCounter = '00:05';
        this.HttpClient.post("http://localhost:3002/settingsAdd", this.SettingClass).subscribe();
      }
    });
  }

  changeStockSettings(){
    if(this.tmpSettingClass.time_start !== '') {
      this.SettingClass.time_start = this.tmpSettingClass.time_start;
    }
    if(this.tmpSettingClass.time_end !== ''){
      this.SettingClass.time_end = this.tmpSettingClass.time_end;
    }
    if(this.tmpSettingClass.intervalCounter !== '') {
      this.SettingClass.intervalCounter = this.tmpSettingClass.intervalCounter;
    }
    this.HttpClient.post("http://localhost:3002/settingsAdd", this.SettingClass).subscribe();
  }
}
