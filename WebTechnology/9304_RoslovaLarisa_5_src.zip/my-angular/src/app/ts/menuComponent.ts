import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: '../html/mainPage.html',
  styleUrls: ['../css/w3Css.css']
})

export class menuComponent { }
