import { Component } from '@angular/core';
import {Share} from "../basicClass/Share";
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-root',
  templateUrl: '../html/share.html',
  styleUrls: ['../css/w3Css.css']
})
export class SharesListComponent {

  tmpShare: Share = new Share(0, '', 0, '', 0,0 );
  ShareList: Share[] = [];
  constructor(public HttpClient: HttpClient) { }

  curShare : number = NaN;

  ngOnInit(){
    this.HttpClient.get("http://localhost:3002/shareGet").subscribe((data: any)=>{
      if(Object.keys(data).length !== 0) {
        this.ShareList = data;
      }
    });
  }

  showModChangeWindow(brok_id_chg: number) {
    this.curShare = brok_id_chg;
  }

  addShare(){
    let newShare = new Share(0, '', 0, '', 0,0 );
    newShare.name = this.tmpShare.name;
    newShare.price = this.tmpShare.price;
    newShare.distribution = this.tmpShare.distribution;
    newShare.change = this.tmpShare.change;
    newShare.amount = this.tmpShare.amount;
    if(this.ShareList.length !== 0) {
      newShare.id = this.ShareList[this.ShareList.length - 1].id + 1;
    }else{
      newShare.id = 0;
    }
    this.cleanTmp();

    this.ShareList[this.ShareList.length] = newShare;
    this.HttpClient.post("http://localhost:3002/shareAdd", this.ShareList).subscribe();
  }

  cleanTmp(){
    this.tmpShare.id = 0;
    this.tmpShare.price = 0;
    this.tmpShare.name = '';
    this.tmpShare.distribution = '';
    this.tmpShare.change = 0;
    this.tmpShare.amount = 0;
  }

  changeShare(){
    for(let i = 0; i < this.ShareList.length; i++){
      if(this.ShareList[i].id === this.curShare){
        if(this.tmpShare.name === '' || this.tmpShare.distribution === '') {
          return;
        }
        this.ShareList[i].name = this.tmpShare.name;
        this.ShareList[i].price = this.tmpShare.price;
        this.ShareList[i].distribution = this.tmpShare.distribution;
        this.ShareList[i].change = this.tmpShare.change;
        this.ShareList[i].amount = this.tmpShare.amount;
        this.HttpClient.post("http://localhost:3002/shareChange", this.ShareList[i]).subscribe();
      }
    }
  }

  deleteShare(id: number){
    for(let i = 0; i < this.ShareList.length; i++){
      if(this.ShareList[i].id === id){
        this.ShareList.splice(i,1);
        this.HttpClient.post("http://localhost:3002/shareDelete", this.ShareList).subscribe();
        break;
      }
    }
  }
}
