import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: '../html/app.html',
  styleUrls: [ ]
})
export class AppComponent { }
