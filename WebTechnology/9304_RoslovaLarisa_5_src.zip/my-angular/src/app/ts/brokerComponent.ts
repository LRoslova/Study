import { Component, OnInit } from '@angular/core';
import { Broker } from "../basicClass/Broker";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-root',
  templateUrl: '../html/broker.html',
  styleUrls: ['../css/w3Css.css']
})

export class BrokerListComponent implements OnInit {
  tmpBroker: Broker = new Broker(0, '', '', 0);
  BrokerList: Broker[] = [];
  constructor(public HttpClient: HttpClient) { }

  curBroker : number = NaN;

  ngOnInit(){
    this.HttpClient.get("http://localhost:3002/brokerAdd").subscribe((data: any)=>{
      if(Object.keys(data).length !== 0) {
        this.BrokerList = data;
      }else{
        this.HttpClient.post("http://localhost:3002/brokerAdd", this.BrokerList).subscribe();
      }
    });
  }

  showModChangeWindow(curBr: number) {
    this.curBroker = curBr;
  }

  addBroker(){
    if(this.tmpBroker.first_name === '' || this.tmpBroker.last_name === ''){
      return;
    }
    let newBroker = new Broker(0, '', '', 0);
    newBroker.first_name = this.tmpBroker.first_name;
    newBroker.last_name = this.tmpBroker.last_name;
    newBroker.money = this.tmpBroker.money;
    if(this.BrokerList.length !== 0) {
      newBroker.id = this.BrokerList[this.BrokerList.length - 1].id + 1;
    }else{
      newBroker.id = 0;
    }
    this.BrokerList[this.BrokerList.length] = newBroker;
    this.HttpClient.post("http://localhost:3002/brokerAdd", this.BrokerList).subscribe();
  }

  changeBroker(){
    for(let i = 0; i < this.BrokerList.length; i++){
      if(this.BrokerList[i].id === this.curBroker){
        this.BrokerList[i].first_name = this.tmpBroker.first_name;
        this.BrokerList[i].last_name = this.tmpBroker.last_name;
        this.BrokerList[i].money = parseInt(String(this.tmpBroker.money));
        this.HttpClient.post("http://localhost:3002/brokerChange", this.BrokerList[i]).subscribe();
      }
    }
  }

  deleteBroker(id: number){
    for(let i = 0; i < this.BrokerList.length; i++){
      if(this.BrokerList[i].id === id){
        this.BrokerList.splice(i,1);
        this.HttpClient.post("http://localhost:3002/brokerDelete", this.BrokerList).subscribe();
        break;
      }
    }
  }
}
